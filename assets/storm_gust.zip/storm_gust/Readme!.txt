By installing or using this font, you are agree to the Product Usage Agreement:

1. This font for PERSONAL USE. No commercial use allowed!
2. If you want to use this font for commercial use you must buy a commercial license.
3. LINK TO PURCHASE COMMERSIAL LICENSE:

===========================================================

https://hanzelspace.com/product/storm-gust-horror-font/

===========================================================

to DONATE click here:
yodikdesigner@yahoo.com

if you need more detailed information you can contact me at:
hanzelgraphic@gmail.com


Thanks,
Hanzel Space